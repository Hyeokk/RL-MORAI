#include <iostream>
#include <numeric>
#include <algorithm>
#include "opencv2/opencv.hpp"
#include <cmath>
#include <math.h>
#include <ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>
#include <sensor_msgs/image_encodings.h>
#include "traffic_light/gostop.h"
#include "waypoint_maker/State.h"


using namespace cv;
using namespace std;

class IMGParser{


private:
    ros::NodeHandle nh_;
    ros::NodeHandle nh;

    ros::Subscriber image_sub , status_sub;
    ros::Publisher vision_check_pub;
    
    
    Mat warped_frame_;
    

    //filter_color    
    Mat red_mask, red_image;
    Mat yellow_mask, yellow_image;
    Mat green_mask, green_image;
/*
    Scalar lower_red = Scalar(150,80,80);
    Scalar upper_red = Scalar(180,255,255);

    Scalar lower_yellow = Scalar(20,20,100);
    Scalar upper_yellow = Scalar(32,255,255);
*/
    Scalar lower_red = Scalar(150,80,80);
    Scalar upper_red = Scalar(180,255,255);

    Scalar lower_yellow = Scalar(30,80,100);
    Scalar upper_yellow = Scalar(40,255,255);
    
    Scalar lower_green = Scalar(50,100,75);
    Scalar upper_green = Scalar(90,255,255);
    
    //Scalar lower_red = Scalar(30,30,100); bgr
    //Scalar upper_red = Scalar(80,80,255);

    //Scalar lower_yellow = Scalar(30,100,100);
    //Scalar upper_yellow = Scalar(80,255,255);
    
    //Scalar lower_green = Scalar(30,100,30);
    //Scalar upper_green = Scalar(80,255,80);

    //ROI
   
     Mat img_edges;
     Mat red_edges,yellow_edges,green_edges;
     Mat total_mask;

   int red_count,yellow_count,green_count;
   int cur_state_;
   int status=1;
    
   traffic_light::gostop go_stop_msg;


public:
    

    IMGParser() {
        initSetup();
    }
    ~IMGParser() {
    }

    void initSetup(){
       image_sub = nh_.subscribe("/image_jpeg/compressed2",100, &IMGParser::imageCallback,this);
       vision_check_pub=nh.advertise<traffic_light::gostop>("gostop",100);
       status_sub = nh_.subscribe("/gps_state", 1, &IMGParser::trafficCallback, this);
     
    }

   void trafficCallback(const waypoint_maker::State::ConstPtr &lane_num) {
	cur_state_ = lane_num->current_state;
}

   void imageCallback(const sensor_msgs::CompressedImage::ConstPtr &image) {
        if(cur_state_==12 || cur_state_==20){
		    cv_bridge::CvImagePtr cv_ptr;
		
		    try {
		    	cv_ptr = cv_bridge::toCvCopy(image, sensor_msgs::image_encodings::BGR8);
		    }
		    catch(cv_bridge::Exception& e) {
			    ROS_ERROR("CV_BRIDGE EXCEPTION: %s", e.what()); 
             return;
		    }   


            warped_frame_=cv_ptr->image;

            int width = warped_frame_.size().width;
	        int height = warped_frame_.size().height;
            resize(warped_frame_, warped_frame_,Size(640,480));

            filter_colors();
       
            red_edges = region_of_interest(red_mask);
            yellow_edges = region_of_interest(yellow_mask);
            green_edges = region_of_interest(green_mask);
            
            total_mask=img_concat(red_edges,yellow_edges,green_edges);
            count_pixels();
            judge_go_stop();
           // imshow("ROI_red",red_edges);
            //imshow("ROI_green",green_edges);
            //imshow("ROI_yellow",yellow_edges);
            //imshow("Image window",warped_frame_);

            waitKey(1);
           }
}



    void filter_colors(){
        
        Mat img_hsv;
        Mat red_yellow,three_mask;
        cvtColor(warped_frame_,img_hsv,COLOR_BGR2HSV);

        //img_hsv = warped_frame_;

        inRange(img_hsv,lower_red,upper_red,red_mask); //red 영역 추출
        bitwise_and(warped_frame_,warped_frame_,red_image,red_mask);//red 부분확인

        inRange(img_hsv,lower_yellow,upper_yellow,yellow_mask); //노란색영역 추출
        bitwise_and(warped_frame_,warped_frame_,yellow_image,yellow_mask);//노란색부분확인

        inRange(img_hsv,lower_green,upper_green,green_mask); //green 영역 추출
        bitwise_and(warped_frame_,warped_frame_,green_image,green_mask);//green 부분확인
        
        hconcat(red_mask,yellow_mask,red_yellow);
        hconcat(red_yellow,green_mask,three_mask);
        //imshow("Red_Yeollow_Green",three_mask);
        
        waitKey(1);

    }


  Mat region_of_interest(Mat img_edges) 

        {
        int width = img_edges.cols;
        int height = img_edges.rows;

          Point points[4];
        points[0] = Point(320,360);
	    points[1] = Point(390,360);
	    points[2] = Point(390,390);
	    points[3] = Point(320,390);
       
        

        Mat img_mask = Mat::zeros(img_edges.rows, img_edges.cols, CV_8UC1); 
        const Point* ppt[1] = { points }; 
        int npt[] = { 4 }; 
        fillPoly(img_mask, ppt, npt, 1, Scalar(255, 255, 255), LINE_8); 
        Mat img_masked;
        bitwise_and(img_edges, img_mask, img_masked);
        resize(img_masked,  img_masked, Size(), 2, 2, CV_INTER_LINEAR);
        return img_masked; 
        
        }


       int count_pixels(){
           
          cout<<"RED pixels :"<<countNonZero(red_edges)<<endl;
          cout<<"YELLOW pixels :"<<countNonZero(yellow_edges)<<endl;
          cout<<"GREEN pixels :"<<countNonZero(green_edges)<<endl;
          red_count =countNonZero(red_edges);
          yellow_count =countNonZero(yellow_edges);
          green_count =countNonZero(green_edges);
          
  
       }


       void judge_go_stop(){
       //cur_state_=1;
		if(cur_state_==12 || cur_state_==20){
		//if(cur_state_==1){
		   	if(green_count>30){
		   		go_stop_msg.vision_check= 1; //true =go
		    		cout<< "GO!"<<endl<<go_stop_msg<<endl;
		   	}
		   	else if(red_count>=20){
		   		go_stop_msg.vision_check= 0; //false =stop
		            	cout<< "STOP!"<<endl<<go_stop_msg<<endl;
		   	}
		   	else if(yellow_count>=20){
		   		go_stop_msg.vision_check= 0; //false =stop
		            	cout<< "STOP!"<<endl<<go_stop_msg<<endl;
		   	}
	       }
		   	/*
		   	else{
		   		go_stop_msg.vision_check= 1; //true =go
		    		cout<< "GO!"<<endl<<go_stop_msg<<endl;
		   	}*/
		   
	   	
	   	/*
	   	else{   
			   if(yellow_count>5){
				    go_stop_msg.vision_check= 0; //false =stop
				    cout<< "STOP!"<<endl<<go_stop_msg<<endl;
				  

			   }
			    else if(red_count>=10){ //stop
				    go_stop_msg.vision_check= 0; //false =stop
				    cout<< "STOP!"<<endl<<go_stop_msg<<endl;               
				  
			    }

			    /*else if(red_count>=10 || green_count>=10){ //2번신호등 직좌시 go 
			    go_stop_msg.vision_check= 1; //true = go
			    cout<< "GO!"<<endl<<go_stop_msg<<endl;
			    
			   
			    
			    }*/
			    /*
			    else{
			    go_stop_msg.vision_check= 1; //true =go
			    cout<< "GO!"<<endl<<go_stop_msg<<endl;
			  
			    
			    }
           	 }
            */
            
            vision_check_pub.publish(go_stop_msg);
 
 
 
            /*1번신호등(적색일때만 멈추면됌)
            else if(red_count>0&&green_count>0) //직좌신호
            go쏴줌
            */


             /*2번신호등(정지좌회전일때 가야하고 나머지 신호때 정지)
            if(red_count>7&&green_count>5) //정지좌회전신호
            -go
            else 
            -stop
            */

            /*3번신호등(적색,노란색등일때 멈추면됌)
            else if(red_count>7||yellow_count>) //직좌신호
            go쏴줌
            */

            
            

       }
        

    Mat img_concat(Mat r_image,Mat y_image,Mat g_image){
        
        Mat merged_first,merged_second;

        hconcat(r_image,y_image,merged_first);
        hconcat(merged_first,g_image,merged_second);
        

        return merged_second;
    }



};
int main(int argc, char **argv) {
    ros::init(argc,argv,"img_parser");
    IMGParser ip;

    while(ros::ok()){
        ros::spinOnce();
    }

    return 0;
}
