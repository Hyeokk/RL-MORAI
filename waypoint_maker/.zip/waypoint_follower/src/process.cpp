#include <ros/ros.h>
#include <waypointFollower.h>

void WaypointFollower::process() 
{
	cout << is_pose_ << ", " << is_course_ << ", " << is_lane_ << endl;
	if(is_pose_ && is_course_ && is_lane_)
	{ 
		is_control_ = true;
		switch(current_mission_state_)
		{
			case 0:
                spd_state_ = 4;
				lookahead_dist_ = STRAGHT_LD;
				dist_ < 15.0 ?  clientCall_turnSignal_off() : clientCall_left_on();
				cout << dist_ << endl;
				break;
			case 1: case 3: case 7: case 11: case 14: case 26: case 28: case 32: //직진, 곡률 작은 커브
				spd_state_ = 4;
				lookahead_dist_ = STRAGHT_LD;
				break;
			case 4: 
				lookahead_dist_ = CURVE_LD;
				if (dist_ <= 10.0) spd_state_ = 6;
				else spd_state_ = 3;

			case 13: case 21: case 27:  // 곡률이 유독 큰 커브
				spd_state_ = 3;
				lookahead_dist_ = BIG_CURVE_LD;
				break;
				
			case 15: case 17: case 25: case 31: // 곡률 큰 커브
				spd_state_ = 3;
				lookahead_dist_ = CURVE_LD;
				break;
			case 2:
				spd_state_ = 3;
				lookahead_dist_ = STRAGHT_LD;
				cout << dist_ << endl;
				if(dist_ < 2.0 && !is_hill_stop_done_)  //오르막
				{
					spd_state_ = 0;
					brake_ = 1;
					if(!start_hill_stop_)
					{
						start_sec_ = ros::Time::now().toSec();
						start_hill_stop_ = true;
					}
					else
					{
						during_sec_ = ros::Time::now().toSec() - start_sec_;
						if(3.5 < during_sec_ && during_sec_ < 4.0)
						{
							is_hill_stop_done_ = true;
							spd_state_ = 8;
						}
					}
				}
				break;
			case 5: //음영구역
				//spd_state_ = 6;
				lookahead_dist_ = CURVE_LD;
				if (!is_vertical_) is_vertical_ = true;
				// if(!is_first_stop_done_)
				// {
				// 	spd_state_ = 2;
				// 	nogps_steering_ = true;
				// 	if(!start_first_stop_)
				// 	{
				// 		start_sec_ = ros::Time::now().toSec();
				// 		start_first_stop_ = true;
				// 	}
				// 	else
				// 	{
				// 		during_sec_ = ros::Time::now().toSec() - start_sec_;
				// 		if(during_sec_ > 2.1)
				// 			is_first_stop_done_ = true;
				// 	}
				// }
				// else nogps_steering_ = false;
				
				// if(!is_third_stop_done_)
				// {
				// 	spd_state_ = 2;
				// 	nogps_steering_2_ = false;
				// 	if(!start_third_stop_)
				// 	{
				// 		start_sec_ = ros::Time::now().toSec();
				// 		start_third_stop_ = true;
				// 	}
				// 	else
				// 	{
				// 		during_sec_ = ros::Time::now().toSec() - start_sec_;
				// 		if(during_sec_ > 12.75)
				// 			is_third_stop_done_ = true;
				// 	}
				// }
				// else nogps_steering_2_ = true;

				break;
			case 8: //음영구역
				spd_state_ = 3;
				lookahead_dist_ = CURVE_LD;
				if(!is_first_stop_done_)
				{
					spd_state_ = 2;
					nogps_steering_ = true;
					if(!start_first_stop_)
					{
						start_sec_ = ros::Time::now().toSec();
						start_first_stop_ = true;
					}
					else
					{
						during_sec_ = ros::Time::now().toSec() - start_sec_;
						if(during_sec_ > 2.1)
							is_first_stop_done_ = true;
					}
				}
				else nogps_steering_ = false;
				
				if(!is_third_stop_done_)
				{
					spd_state_ = 2;
					nogps_steering_2_ = false;
					if(!start_third_stop_)
					{
						n_gps_start_sec_ = ros::Time::now().toSec();
						start_third_stop_ = true;
					}
					else
					{
						during_sec_ = ros::Time::now().toSec() - n_gps_start_sec_;
						if(during_sec_ > 12.75)
							is_third_stop_done_ = true;
					}
				}
				else nogps_steering_2_ = true;
				break;
			case 9:		//동적
				spd_state_ = 3;
				lookahead_dist_ = STRAGHT_LD;
				if(is_obs_detect_dy_ && dist_ < 14.0)
				{
					is_dynamic_finished_ = true;
					nh_.setParam("/waypoint_follower_node/is_dynamic_finished", is_dynamic_finished_);
					spd_state_ = 0;
					clientCall_emergency_on();
				}
				else clientCall_emergency_off();
				break;
			case 12:   //동적
				lookahead_dist_ = CURVE_LD;
				if(is_dynamic_finished_) spd_state_ = 4;
				else
				{
					spd_state_ = 2;
					if(is_obs_detect_dy_ && dist_ < 14.0 && !is_dynamic_finished_) 
					{
						spd_state_ = 0;
						clientCall_emergency_on();
					}
					else if(cur_speed_ <= 0.1 && !is_obs_detect_dy_)
					{
						clientCall_emergency_off();			
						is_dynamic_finished_ = true;                
					}    
				}
				break;
			case 16: //동적
				lookahead_dist_ = STRAGHT_LD;
				if(is_dynamic_finished_) spd_state_ = 4;
				else 
				{
					spd_state_ = 2; //빠르게 가다가
					if(5.0 < dist_ && dist_ < 15.0)
					{
						spd_state_ = 1;
						if(is_obs_detect_dy_) 
						{
							spd_state_ = 0;
							clientCall_emergency_on();
						}
						else clientCall_emergency_off();
					}
				}
				break;
			case 18: //주차 시작
				lookahead_dist_ = PARKING_LD;
				if (parking_count_ != -1)
				{
					spd_state_ = 1;
					parking_count_ = -1;
					nh_.setParam("/waypoint_loader_node/parking_count", parking_count_);
				}
				break;
			case 19:
				lookahead_dist_ = PARKING_LD;
				spd_state_ = 1;
				break;

			case 20:
				lookahead_dist_ = PARKING_LD;
				spd_state_ = 2;
				break;
			case 6: case 10:
				if (is_vertical_) is_vertical_ = false;
				lookahead_dist_ = STRAGHT_LD;
				spd_state_ = 4; // 빠르게.
				if(dist_ <= 3.5) 
				{
					spd_state_ = 1; // 속도 줄이기.
					if(!vision_check_) spd_state_ = 0;
				}
				break;
			case 22:
				lookahead_dist_ = STRAGHT_LD;
				spd_state_ = 4; // 빠르게.
				if (dist_ <= 10.0)
				{
					clientCall_left_on();
					if (dist_ <= 3.5) 
					{
						spd_state_ = 1; // 속도 줄이기.
						if(!vision_check_) spd_state_ = 0;
					}
				}
				break;
			case 23:
				lookahead_dist_ = BIG_CURVE_LD;
				spd_state_ = 3;
				dist_ < 2.0 ? clientCall_turnSignal_off() : clientCall_left_on();
				break;
			case 24:
				lookahead_dist_ = STRAGHT_LD;
				spd_state_ = 4;
				clientCall_turnSignal_off();
				break;
			case 29:
				lookahead_dist_ = STRAGHT_LD;
				spd_state_ = 4;
				accel_ = 1.0;
				if(dist_ <= 20) brake_ = 0.4;
				break;
			case 30:
				lookahead_dist_ = STRAGHT_LD;
				accel_ = 0.0;
				brake_ = 1.0;
				if(cur_speed_ <= 30) brake_ = 0.4;
				break;
			case 33:
				lookahead_dist_ = STRAGHT_LD;
				spd_state_ = 4;
				if(dist_ < 27.0) clientCall_right_on();
				
				if(dist_ < 7.0)
				{
					spd_state_ = 0;
					gear_parking();
				}
				break;
			default: cerr << "!!!Mission State Error!!!" << endl;
				break;
		}


	//*************** 좌회전 *************** //

		// else if(current_mission_state_ == 20) { // 좌회전
		// 	spd_state_ = 3;
		// 	clientCall_left_on();
		// 	if(dist_ <=4.0) {
		// 		spd_state_ = 1;
		// 		if(!vision_check_) spd_state_ = 0;
		// 		else spd_state_ = 4; // 좌회전 신호 받을 때.
		// 	}
		// 	/*if(dist_ <=0.5)// 깜빡이 끄기.
		// 	    clientCall_turnSignal_off();*/
			
		// }
		// else if(current_mission_state_ == 20) { // 좌회전.
		// 	spd_state_ = 3;
		//



	//////////////////////  주차  //////////////////////////////////////////

		if(parking_count_ == -1) 
		{//전진
			spd_state_ = 5;
			if(dist_ <= 3.0)
			{ 
				parking_count_ = 0;
				spd_state_ = 0;
				is_backward_ = true;
				nh_.setParam("/waypoint_loader_node/parking_count", parking_count_);
			}
		}
		
		else if (parking_count_ == 0) 
		{	
			if(!gear_flag)
			{
				start_sec_ = ros::Time::now().toSec();
				gear_flag = true;
				spd_state_ = 0;
			}
			else
			{
				during_sec_ = ros::Time::now().toSec() - start_sec_;
				if(during_sec_ <= 1.0)
				{
					spd_state_ = 0;
					gear_rear();
				}
				else 
				{
					spd_state_ = 5;
					if (dist_<= 3.7)
					{  
						parking_count_ = 1;
						nh_.setParam("/waypoint_loader_node/parking_count", parking_count_);
						spd_state_ = 0;	
						is_backward_ = false;
						gear_flag = false;
					}
				}
			}
								
		}
		
		else if (parking_count_ == 1) 
		{
			if(!gear_flag)
			{
				start_sec_ = ros::Time::now().toSec();
				gear_flag = true;
				spd_state_ = 0;
			}
			else
			{
				during_sec_ = ros::Time::now().toSec() - start_sec_;
				if(during_sec_ <= 1.0)
				{
					spd_state_ = 0;
					gear_drive();
				}
				else 
				{
					spd_state_ = 1;
					if (dist_< 7.0)
					{  
						parking_count_ = -3;
						nh_.setParam("/waypoint_loader_node/parking_count", parking_count_);
						spd_state_ = 1;	
						gear_flag = false;
					}
				}
			}
		}

		cout << "current state : "<< current_mission_state_ << endl;
		cout << "dist : "<< dist_ << endl;
	}
	
		//////////////////////////////////////////////////
	
	if (is_control_) 
	{ 
		switch(spd_state_)
		{
			case (int)Speed_Opt::Stop: speed_ = 0; brake_ = 1;
				break;
			case (int)Speed_Opt::Vel_10: speed_ = 10.0;
				break;
			case (int)Speed_Opt::Vel_14: speed_ = 14.0;
				break;
			case (int)Speed_Opt::Vel_17: speed_ = 17.0;
				break;
			case (int)Speed_Opt::Vel_19: speed_ = 19.0;
				break;
			case (int)Speed_Opt::Parking_vel: speed_ = 5.0;
				break;
			case (int)Speed_Opt::Vertical: speed_ = 4.0;
				break;
			case (int)Speed_Opt::Fast: speed_ = 50.0;
				break;
			default: cerr << "!!!Speed State Error!!!" << endl;
				break;
		}
		
		speed_ = PID(speed_, cur_speed_);
		cur_steer = calcSteeringAngle();
		cout << "steer :: " << cur_steer << endl;

		// GPS음영지역(차선)
		if(current_mission_state_ == 8)
		{
            speed_ = 17.0;
            cur_steer = camera_angle_*1.8;
			cout << "차량 조향각 ==  " << cur_steer << endl;
			
            if(during_sec_ > 11.5)
			{
                speed_ = 14;
            	cur_steer = camera_angle_ * 2.0;
			}

            if(nogps_steering_)
                cur_steer = -0.45; // cur_steer = -0.3;
            else if(nogps_steering_2_ && n_gps_during_sec_ < 29.5) //14.6
			{
				cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
                n_gps_during_sec_ =  ros::Time::now().toSec() - n_gps_start_sec_;
                cur_steer = -0.45;
            }

        }




		//가속구간
		if(current_mission_state_ == 29 || (current_mission_state_ == 30 && cur_speed_ >= 20)) 
		{
		    ackermann_msg_.longlCmdType = 1;
		    ackermann_msg_.accel = accel_;
		    ackermann_msg_.brake = .0;
		    ackermann_msg_.steering = cur_steer;
		}
		else if(current_mission_state_ != 29) 
		{
		    ackermann_msg_.longlCmdType = 2;
		    ackermann_msg_.velocity = speed_;
		    ackermann_msg_.brake = brake_;
		    ackermann_msg_.steering = cur_steer;
		
		}
		if (!is_vertical_)
			ackermann_pub_.publish(ackermann_msg_);
	}

	is_pose_ = false;
	is_course_ = false;
	cout << "IS DYNAMIC FINISHED    ::    "   << is_dynamic_finished_ << endl;
	cout << "CUR_SPEED  ::   "  << cur_speed_ << endl;
    cout << "-------------------------------- " << endl;
}

