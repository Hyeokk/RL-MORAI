#include <ros/ros.h>
#include <iostream>

#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/filters/passthrough.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/normal_3d.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>

#include "sensor_msgs/PointCloud2.h"
#include "pcl_ros/point_cloud.h"

#include "dynamic_stop/DynamicMsg.h"

#include "waypoint_maker/State.h"
using namespace std;
typedef pcl::PointXYZ pointType;

class Dynamic {
private:
    ros::NodeHandle nh_;
    ros::Publisher pub_centers_, pub_points_, stop_pub_, pub_control_;
    ros::Subscriber sub_, point_sub_;

	//msg
    dynamic_stop::DynamicMsg dynamic_msgs;
    
	//local variable
	pcl::PointCloud<pointType>::Ptr cloud;
    int go_sign_ = 0;
    int cur_state_;
	bool dynamic_finish_ = false;
    
    //param
    int count_;
    float tol_, min_size_, max_size_;
    
    int param_state;

public:
    void scanCallback(const sensor_msgs::PointCloud2ConstPtr &scan);
    void stateCallback(const waypoint_maker::State::ConstPtr &state);
   
    void initSetup();
   	void run();
    bool clustering();
    

    Dynamic(){
    	cout<<"In dynamic_mission state(6)"<<endl;  
    	cloud.reset(new pcl::PointCloud<pointType>());	
        initSetup();
	}
    
    ~Dynamic(){
    	cout<<"dynamic_mission is done!"<<endl;  	
    }
};

void Dynamic::initSetup(){
    point_sub_ = nh_.subscribe("/points_no_ground", 10, &Dynamic::scanCallback, this);
    sub_ = nh_.subscribe("/gps_state",10,&Dynamic::stateCallback,this);
    pub_points_ = nh_.advertise<sensor_msgs::PointCloud2>("/cloud_filtered", 10);
    stop_pub_ = nh_.advertise<dynamic_stop::DynamicMsg>("/dynamic_msg", 1);
    dynamic_msgs.is_obs = false;
    dynamic_msgs.no_dynamic = false;
    dynamic_msgs.is_finish = false;
    
	ros::param::get("~tol", tol_);
	ros::param::get("~min_size", min_size_);
	ros::param::get("~max_size", max_size_);
	
	
    ros::param::get("~count", count_);
    
    ros::param::get("~param_state", param_state);

    //cur_state_=777; //임의 값    
}

void Dynamic::stateCallback(const waypoint_maker::State::ConstPtr &state){
	cur_state_ = state->current_state;
}

void Dynamic::scanCallback(const sensor_msgs::PointCloud2::ConstPtr &scan) {
		pcl::fromROSMsg(*scan, *cloud);
}

void Dynamic::run()
{
    cout<<"Sate: "<<cur_state_<<endl;
	if(cur_state_==5 || cur_state_==9 || cur_state_==13){
         if(clustering()){
         			    
                     
                     dynamic_msgs.is_obs = true;
                     dynamic_finish_=true;
                     cout<<"Stop"<<endl;
                     
                     stop_pub_.publish(dynamic_msgs);
              
             		
        }
         else {
            
             dynamic_msgs.no_dynamic =false;
             dynamic_msgs.is_obs = false;
             cout<<"Go"<<endl;
             stop_pub_.publish(dynamic_msgs);
         }
      
    }
	
	else {
            
             dynamic_msgs.no_dynamic =false;
             dynamic_msgs.is_obs = false;
             cout<<"Go"<<endl;
             stop_pub_.publish(dynamic_msgs);
         }
}

bool Dynamic::clustering(){
   
    pcl::search::KdTree<pointType>::Ptr kdtree(new pcl::search::KdTree<pointType>);
    kdtree -> setInputCloud(cloud);

    std::vector<pcl::PointIndices> clusterIndices;
    pcl::EuclideanClusterExtraction<pointType> ec;

    ec.setClusterTolerance(tol_);
    ec.setMinClusterSize(min_size_);
    ec.setMaxClusterSize(max_size_);
    ec.setSearchMethod(kdtree);
    ec.setInputCloud(cloud);
    ec.extract(clusterIndices);

    
    if (clusterIndices.size()!=0) {return true;}
    else {return false;}
    
}



int main(int argc, char **argv){
    ros::init(argc, argv, "dynamic_stop_node");
    
    Dynamic dynamic;
    ros::Rate loop_rate(10);
    
	while(ros::ok()){
	    //cout<<"###### dynamic_stop ######"<<endl;	
		ros::spinOnce();
		dynamic.run();
		loop_rate.sleep();
	}
	
	return 0;
	
    
}
