
#include <ros/ros.h>
#include <iostream>

#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/filters/passthrough.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/normal_3d.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl_conversions/pcl_conversions.h>
#include "sensor_msgs/PointCloud2.h"
#include "pcl_ros/point_cloud.h"
#include <pcl/common/centroid.h>
#include <pcl/common/common.h>
#include <pcl/common/transforms.h>

#include "dynamic_stop/DynamicMsg.h"

#include "waypoint_maker/State.h"

#include <morai_msgs/CtrlCmd.h>

#include <pcl/filters/filter.h>
#include <pcl/filters/conditional_removal.h>
#include <visualization_msgs/Marker.h>

// 카메라 헤더

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>

#include <yolov5_cone/BoundingBox.h>
#include <yolov5_cone/BoundingBox_vector.h>


//======= 기타 등등 선언
using namespace cv;
using namespace std;
typedef pcl::PointXYZI pointType;
// cone
struct box_size{
	int id;
	int x_coord;
	int y_coord;
	int w_coord;
	int h_coord;
};



//======


//===


const int region_max_ = 8;
bool cmp(const pcl::PointXYZI &v1, const pcl::PointXYZI &v2);

class Dynamic {
private:
//========fusion 회전변환 행렬 등등
	float distMat[9] = {320, 0, 320,   0, 320, 240,     0, 0, 1};
	float distCoef[5] = {0,0,0,0,0};
	cv::Mat cameraMatrix = Mat(3,3, CV_32F,distMat);
	cv::Mat distCoeffs = Mat(5,1, CV_32F,distCoef);
	float rotation_vector[3] = {1.296022173441048, -1.30629852336684, 1.159085373220065};
	float translation_vector[3] = {0.0615362715007612, 0.3217157722943973, 1.95777335755229};
	cv::Mat rotationvector = Mat(3, 1, CV_32F, rotation_vector);
	cv::Mat translationvector = Mat(3, 1, CV_32F, translation_vector);
	vector<box_size> box;
	
	Mat frame;

	ros::NodeHandle nh_;
	ros::Publisher pub_center_,pub_center_dynamic, pub_points_, stop_pub_, ctrl_pub_;
	ros::Subscriber sub_, point_sub_,sub_cam,darknet;

//===============cloud
	pcl::PointCloud<pcl::PointXYZI>::Ptr cloud;
	pcl::PointCloud<pcl::PointXYZI>::Ptr filteredCld;
	pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_output;

//=============== vector
	vector<pcl::PointCloud<pcl::PointXYZI>> clusters_output_temp;
	vector<pcl::PointXYZI> dynamic_center,center_;

	vector<Point2d> point2D;
	vector<Point3d> point3D;
	
	vector<int> dynamic_index;

	// variables in adaptive clustering
	size_t cluster_size_min_;
	size_t cluster_size_max_;
	int regions_[100];


	//msg
	dynamic_stop::DynamicMsg dynamic_msgs;
	morai_msgs::CtrlCmd ctrl_msg;
	//ackermann_msgs::AckermannDriveStamped steering_msgs;
    
	int cur_state_;
	
    ros::Time stamp;
	double now_time = 0;
	ros::Duration differ_;
	bool flag = false;

	int button = 0;
	
	//param
	int count_;
	double tol_;
	int min_size_, max_size_;

	int param_state;

	int x_min,x_max,y_min,y_max;
	double time_,dist_;



public:
	// call back
	void scanCallback(const sensor_msgs::PointCloud2ConstPtr &scan);
	void stateCallback(const waypoint_maker::State::ConstPtr &state);
	void DarknetCallback(const yolov5_cone::BoundingBox_vector::ConstPtr &darknet_msg);
	void imageCallback(const sensor_msgs::CompressedImage::ConstPtr &msg);
	
	// function
	void initSetup();
	void run();
	void clustering();
	void pt_center();
	void visualize_center(vector<pcl::PointXYZI> input_points);

	// adaptive
	bool is_in_vector(vector<int> v, int element);
	void init_parameters(string sensor_model);
	void adaptive_cluster(pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_in, 		vector<pcl::PointCloud<pcl::PointXYZI>> &clusters_out_temp, int C, pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_out);
	
	//sensor fusion
	void matching();
	void check_box(vector<Point2d> point2D);
	bool is_in_box(int x, int y,int l, int r, int u, int d);
	void clear_vec();
	void stop();
	void vertical();
	void set_roi(int C);

	
	//
    Dynamic(){
    	cout<<"In dynamic_mission state(6)"<<endl;  
    	cloud.reset(new pcl::PointCloud<pointType>());	
        initSetup();
	}
    
    ~Dynamic(){
    	//cout<<"dynamic_mission is done!"<<endl;  	
    }
};
