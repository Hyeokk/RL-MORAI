#pragma once

#include <ros/ros.h>

// For disable PCL complile lib, to use PointXYZIR
#define PCL_NO_PRECOMPILE

#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_types.h>
#include <pcl/conversions.h>
#include <pcl_ros/transforms.h>
#include <pcl_ros/point_cloud.h>
#include <pcl/filters/filter.h> 
#include <pcl/common/centroid.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/passthrough.h>

// using eigen lib
#include <Eigen/Dense>
#include <sensor_msgs/PointCloud2.h>

//mission state
#include "waypoint_maker/State.h"
using namespace std;

namespace velodyne_pointcloud
{
/** Euclidean Velodyne coordinate, including intensity and ring number. */
struct PointXYZIR
{
  PCL_ADD_POINT4D;                // quad-word XYZ
  float intensity;                ///< laser intensity reading
  uint16_t ring;                  ///< laser ring number
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW // ensure proper alignment
} EIGEN_ALIGN16;

}; // namespace velodyne_pointcloud

POINT_CLOUD_REGISTER_POINT_STRUCT(velodyne_pointcloud::PointXYZIR,
                                  (float, x, x)(float, y, y)(float, z, z)(float, intensity, intensity)(uint16_t, ring, ring))

//Customed Point Struct for holding clustered points
namespace plane_ground_filter
{
/** Euclidean Velodyne coordinate, including intensity and ring number, and label. */
struct PointXYZIRL
{
  PCL_ADD_POINT4D;                // quad-word XYZ
  float intensity;                ///< laser intensity reading
  uint16_t ring;                  ///< laser ring number
  uint16_t label;                 ///< point label
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW // ensure proper alignment
} EIGEN_ALIGN16;

}; // namespace plane_ground_filter

#define SLRPointXYZIRL plane_ground_filter::PointXYZIRL
#define VPoint velodyne_pointcloud::PointXYZIR
#define RUN pcl::PointCloud<SLRPointXYZIRL>

// Register custom point struct according to PCL
POINT_CLOUD_REGISTER_POINT_STRUCT(plane_ground_filter::PointXYZIRL,
                                  (float, x, x)(float, y, y)(float, z, z)(float, intensity, intensity)(uint16_t, ring, ring)(uint16_t, label, label))

using Eigen::JacobiSVD;
using Eigen::MatrixXf;
using Eigen::VectorXf;

class PlaneGroundFilter
{

private:
  ros::Subscriber sub_point_cloud_, sub_cur_state_;
  ros::Publisher pub_ground_, pub_no_ground_, pub_all_points_;
  std::string point_topic_;

  int sensor_model_;
  double sensor_height_,th_dist_;
  int num_seg_ = 1;
  int num_iter_, num_lpr_;
  
  // Model parameter for ground plane fitting
  // The ground plane model is: ax+by+cz+d=0
  // Here normal:=[a,b,c], d=d
  // th_dist_d_ = threshold_dist - d
  float d_, th_dist_d_;
  MatrixXf normal_;
  
  float x_min_sb_, x_max_sb_, y_min_sb_, y_max_sb_, z_min_sb_, z_max_sb_;
  float x_min_p_, x_max_p_, y_min_p_, y_max_p_, z_min_p_, z_max_p_;
  float x_min_, x_max_, y_min_, y_max_, z_min_, z_max_;
  bool roi_flag_;

  pcl::PointCloud<VPoint>::Ptr g_seeds_pc;
  pcl::PointCloud<VPoint>::Ptr g_ground_pc;
  pcl::PointCloud<VPoint>::Ptr g_not_ground_pc;
  pcl::PointCloud<SLRPointXYZIRL>::Ptr g_all_pc;

  void estimate_plane_(void);
  void point_cb(const sensor_msgs::PointCloud2ConstPtr &in_cloud);
  
  int cur_state_; 
  void stateCallback(const waypoint_maker::State::ConstPtr &state);
  void set_roi();
  int static_big_state_, parking_state_;

public:
  PlaneGroundFilter(ros::NodeHandle &nh);
  ~PlaneGroundFilter();
  void Spin();
};
