# 다운로드 방법

패키지 내에 morai_msgs가 이미 존재하는 경우(morai_msgs를 포함하지 않고 다운)
    <pre><code>git clone https://github.com/morai-developergroup/autoware_msgs.git</code></pre>
    
패키지 내에 morai_msgs가 없는 경우(morai_msgs를 포함해서 다운)
    <pre><code>git clone https://github.com/morai-developergroup/autoware_msgs.git --recursive</code></pre>
    
