# Factor test

## 04.28 test(화성 1차 테스트)
* Order: `detect_y_offset/yaw_factor/lateral_factor/throttle`
* `60/50/80/16` : too bad -> sol: detect_y_offset을 작게해야 할듯(더 멀리봐야)
* `45/40/80/16` : too bad
* `25/40/80/16` : good 
