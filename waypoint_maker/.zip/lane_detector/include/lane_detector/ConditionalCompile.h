// for Conditional Compilation

#define RC_CAR 0
#define SCALE_PLATFORM 1

#define WEBCAM 1
#define PROSILICA_GT_CAM 0

#define DEBUG 0
